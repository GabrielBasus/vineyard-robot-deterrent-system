from __future__ import annotations

import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
import itertools
import json
import os
from pathlib import Path
from typing import Dict, List

import numpy as np
import pandas as pd

import DeterrentSystem_assignment_lab as ds
from run_assignment_method_comparison_lab import _baseline_cfg


DEFAULT_BASELINES = ["prediction_only", "proposed"]
DEFAULT_METHODS = ["frozen_greedy", "hungarian"]


def _parse_float_list(txt: str) -> List[float]:
    return [float(x.strip()) for x in str(txt).split(",") if x.strip()]


def _parse_int_list(txt: str) -> List[int]:
    return [int(float(x.strip())) for x in str(txt).split(",") if x.strip()]


def _parse_str_list(txt: str) -> List[str]:
    return [x.strip() for x in str(txt).split(",") if x.strip()]


def _ci95(series: pd.Series) -> float:
    x = pd.to_numeric(series, errors="coerce").dropna().to_numpy(dtype=float)
    n = x.size
    if n <= 1:
        return float("nan")
    return float(1.96 * np.std(x, ddof=1) / np.sqrt(n))


def _stats(df: pd.DataFrame, col: str) -> dict:
    s = pd.to_numeric(df[col], errors="coerce").dropna()
    if len(s) == 0:
        return {"mean": float("nan"), "std": float("nan"), "ci95": float("nan"), "n": 0}
    return {
        "mean": float(s.mean()),
        "std": float(s.std(ddof=1)) if len(s) > 1 else 0.0,
        "ci95": _ci95(s),
        "n": int(len(s)),
    }


def _build_base_params(t_end: float, dt: float) -> dict:
    return {
        "W": 500.0,
        "H": 500.0,
        "NX": 80,
        "NY": 64,
        "Nrobots": 6,
        "uav_fraction": 0.0,
        "warmup_s": 1800.0,
        "forecast_horizon_s": 300.0,
        "forecast_match_radius_m": 20.0,
        "forecast_top_k": 5,
        "forecast_eval_period_s": 30.0,
        "task_replan_period_s": 45.0,
        "model_deterring_window_s": 90.0,
        "model_deterring_risk_threshold": 0.35,
        "model_deterring_budget_per_robot_per_hr": 4,
        "model_deterring_min_recent_points": 1,
        "telemetry_clear_on_start": False,
        "telemetry_prompt_save": False,
        "collect_time_metrics": False,
        "T_end": float(t_end),
        "dt": float(dt),
    }


def _empty_runs_df() -> pd.DataFrame:
    return pd.DataFrame(
        columns=[
            "scenario_id",
            "assignment_distance_cost_per_m",
            "assignment_switch_penalty",
            "task_replan_period_s",
            "model_deterring_risk_threshold",
            "model_deterring_budget_per_robot_per_hr",
            "model_deterring_window_s",
            "beta_true",
            "baseline",
            "assignment_method",
            "seed",
            "run_idx",
            "value_weighted_exposure",
            "mean_response_time_s",
            "boundary_message_count",
            "boundary_bytes_sent",
            "tasks_per_unit_distance",
            "assignment_solver_runtime_ms",
            "assignment_solver_calls",
            "assignment_solver_conflicts_resolved",
            "assignment_solver_unassigned",
            "assignment_solver_rounds_mean",
            "assignment_solver_bid_updates",
            "assignment_solver_message_passes",
            "assignment_solver_failures",
            "assignment_solver_feasible_edge_rate",
        ]
    )


def _load_checkpoint(path: Path) -> pd.DataFrame:
    if path.exists():
        try:
            df = pd.read_csv(path)
            return df
        except Exception:
            return _empty_runs_df()
    return _empty_runs_df()


def _write_checkpoint(path: Path, runs_df: pd.DataFrame, progress: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    runs_df.to_csv(path, index=False)
    progress_path = path.with_suffix(".progress.json")
    progress_path.write_text(json.dumps(progress, indent=2), encoding="utf-8")


def _pair_complete(
    runs_df: pd.DataFrame,
    scenario_id: str,
    baseline: str,
    method: str,
    num_runs: int,
) -> bool:
    if runs_df.empty:
        return False
    sub = runs_df[
        (runs_df["scenario_id"] == scenario_id)
        & (runs_df["baseline"] == baseline)
        & (runs_df["assignment_method"] == method)
    ]
    if len(sub) < int(num_runs):
        return False
    seeds = sorted(pd.to_numeric(sub["seed"], errors="coerce").dropna().astype(int).unique().tolist())
    return len(seeds) >= int(num_runs)


def _drop_pair_rows(runs_df: pd.DataFrame, scenario_id: str, baseline: str, method: str) -> pd.DataFrame:
    if runs_df.empty:
        return runs_df
    keep = ~(
        (runs_df["scenario_id"] == scenario_id)
        & (runs_df["baseline"] == baseline)
        & (runs_df["assignment_method"] == method)
    )
    return runs_df[keep].copy()


def _run_combo_job(payload: dict) -> dict:
    # Worker entrypoint: keep top-level for Windows multiprocessing pickling.
    baseline = str(payload["baseline"])
    method = str(payload["method"])
    c_dist = float(payload["assignment_distance_cost_per_m"])
    c_switch = float(payload["assignment_switch_penalty"])
    replan_s = float(payload["task_replan_period_s"])
    risk_th = float(payload["model_deterring_risk_threshold"])
    budget_hr = int(payload["model_deterring_budget_per_robot_per_hr"])
    det_window_s = float(payload["model_deterring_window_s"])
    beta_true = float(payload["beta_true"])
    scenario_id = str(payload["scenario_id"])

    if getattr(ds, "mon", None) is not None:
        ds.mon.enabled = False

    kwargs = dict(payload["base_params"])
    kwargs.update(_baseline_cfg(baseline))
    kwargs.update(
        {
            "assignment_method": method,
            "assignment_distance_cost_per_m": c_dist,
            "assignment_switch_penalty": c_switch,
            "task_replan_period_s": replan_s,
            "model_deterring_risk_threshold": risk_th,
            "model_deterring_budget_per_robot_per_hr": budget_hr,
            "model_deterring_window_s": det_window_s,
            "beta_true": beta_true,
        }
    )

    out = ds.run_metrics_experiments(
        num_runs=int(payload["num_runs"]),
        seed_start=int(payload["seed_start"]),
        report_each_run=False,
        **kwargs,
    )

    rows: List[dict] = []
    run_list = list(out.get("runs", []))
    for run_i, m in enumerate(run_list):
        seed = int(payload["seed_start"]) + int(run_i)
        rows.append(
            {
                "scenario_id": scenario_id,
                "assignment_distance_cost_per_m": c_dist,
                "assignment_switch_penalty": c_switch,
                "task_replan_period_s": replan_s,
                "model_deterring_risk_threshold": risk_th,
                "model_deterring_budget_per_robot_per_hr": budget_hr,
                "model_deterring_window_s": det_window_s,
                "beta_true": beta_true,
                "baseline": baseline,
                "assignment_method": method,
                "seed": int(seed),
                "run_idx": int(run_i),
                "value_weighted_exposure": float(m.get("value_weighted_exposure", np.nan)),
                "mean_response_time_s": float(m.get("mean_response_time_s", np.nan)),
                "boundary_message_count": float(m.get("boundary_message_count", np.nan)),
                "boundary_bytes_sent": float(m.get("boundary_bytes_sent", np.nan)),
                "tasks_per_unit_distance": float(m.get("tasks_per_unit_distance", np.nan)),
                "assignment_solver_runtime_ms": float(m.get("assignment_solver_runtime_ms", np.nan)),
                "assignment_solver_calls": float(m.get("assignment_solver_calls", np.nan)),
                "assignment_solver_conflicts_resolved": float(m.get("assignment_solver_conflicts_resolved", np.nan)),
                "assignment_solver_unassigned": float(m.get("assignment_solver_unassigned", np.nan)),
                "assignment_solver_rounds_mean": float(m.get("assignment_solver_rounds_mean", np.nan)),
                "assignment_solver_bid_updates": float(m.get("assignment_solver_bid_updates", np.nan)),
                "assignment_solver_message_passes": float(m.get("assignment_solver_message_passes", np.nan)),
                "assignment_solver_failures": float(m.get("assignment_solver_failures", np.nan)),
                "assignment_solver_feasible_edge_rate": float(m.get("assignment_solver_feasible_edge_rate", np.nan)),
            }
        )
    return {
        "scenario_id": scenario_id,
        "baseline": baseline,
        "assignment_method": method,
        "rows": rows,
    }


def run_sweep(
    num_runs: int,
    seed_start: int,
    baselines: List[str],
    methods: List[str],
    distance_costs: List[float],
    switch_penalties: List[float],
    replan_periods_s: List[int],
    risk_thresholds: List[float],
    budget_per_hr: List[int],
    deterring_window_s: List[float],
    beta_true_values: List[float],
    base_params: dict,
    checkpoint_path: Path | None = None,
    resume: bool = True,
    max_workers: int = 1,
) -> pd.DataFrame:
    if checkpoint_path is not None and resume:
        runs_df = _load_checkpoint(checkpoint_path)
    else:
        runs_df = _empty_runs_df()

    combos = list(
        itertools.product(
            distance_costs,
            switch_penalties,
            replan_periods_s,
            risk_thresholds,
            budget_per_hr,
            deterring_window_s,
            beta_true_values,
        )
    )
    total = len(combos) * len(baselines) * len(methods)
    idx = 0

    if int(max_workers) <= 0:
        max_workers = max(1, int(os.cpu_count() or 1) - 1)
    worker_count = int(max_workers)

    for c_dist, c_switch, replan_s, risk_th, budget_hr, det_window_s, beta_true in combos:
        scenario_id = (
            f"d{c_dist:g}_s{c_switch:g}_rp{int(replan_s)}"
            f"_rt{risk_th:g}_bh{int(budget_hr)}_dw{det_window_s:g}_bt{beta_true:g}"
        )
        jobs = []
        for baseline in baselines:
            for method in methods:
                idx += 1
                if _pair_complete(runs_df, scenario_id, baseline, method, int(num_runs)):
                    print(
                        f"[skip] {idx}/{total} scenario={scenario_id} baseline={baseline} "
                        f"method={method} (checkpoint complete)"
                    )
                    continue
                print(f"[queue] {idx}/{total} scenario={scenario_id} baseline={baseline} method={method}")
                jobs.append(
                    {
                        "scenario_id": scenario_id,
                        "baseline": str(baseline),
                        "method": str(method),
                        "assignment_distance_cost_per_m": float(c_dist),
                        "assignment_switch_penalty": float(c_switch),
                        "task_replan_period_s": float(replan_s),
                        "model_deterring_risk_threshold": float(risk_th),
                        "model_deterring_budget_per_robot_per_hr": int(budget_hr),
                        "model_deterring_window_s": float(det_window_s),
                        "beta_true": float(beta_true),
                        "base_params": dict(base_params),
                        "num_runs": int(num_runs),
                        "seed_start": int(seed_start),
                    }
                )

        if not jobs:
            continue

        if worker_count == 1:
            results = [(_run_combo_job(job), job) for job in jobs]
        else:
            with ProcessPoolExecutor(max_workers=worker_count) as executor:
                future_to_job = {executor.submit(_run_combo_job, job): job for job in jobs}
                results = []
                for fut in as_completed(future_to_job):
                    results.append((fut.result(), future_to_job[fut]))

        for res, job in results:
            rows = list(res.get("rows", []))
            if rows:
                baseline = str(res["baseline"])
                method = str(res["assignment_method"])
                runs_df = _drop_pair_rows(runs_df, scenario_id, baseline, method)
                add_df = pd.DataFrame(rows)
                if runs_df.empty:
                    runs_df = add_df.copy()
                else:
                    runs_df = pd.concat([runs_df, add_df], ignore_index=True)

            if checkpoint_path is not None:
                progress = {
                    "checkpoint_version": 3,
                    "num_rows": int(len(runs_df)),
                    "last_completed_scenario": str(scenario_id),
                    "last_completed_pair": {
                        "baseline": str(job["baseline"]),
                        "assignment_method": str(job["method"]),
                    },
                    "num_runs": int(num_runs),
                    "seed_start": int(seed_start),
                    "baselines": list(baselines),
                    "methods": list(methods),
                    "max_workers": int(worker_count),
                }
                _write_checkpoint(checkpoint_path, runs_df, progress)
                print(
                    f"[checkpoint] scenario={scenario_id} baseline={job['baseline']} "
                    f"method={job['method']} total_rows={len(runs_df)}"
                )

    if not runs_df.empty:
        runs_df = runs_df.sort_values(
            by=["scenario_id", "baseline", "assignment_method", "seed", "run_idx"],
            ascending=[True, True, True, True, True],
        ).reset_index(drop=True)

    return runs_df


def build_summary(runs_df: pd.DataFrame) -> pd.DataFrame:
    if runs_df.empty:
        return pd.DataFrame()
    metrics = [
        "value_weighted_exposure",
        "mean_response_time_s",
        "boundary_message_count",
        "tasks_per_unit_distance",
        "assignment_solver_runtime_ms",
        "assignment_solver_rounds_mean",
        "assignment_solver_message_passes",
        "assignment_solver_failures",
    ]
    out = []
    gcols = [
        "scenario_id",
        "assignment_distance_cost_per_m",
        "assignment_switch_penalty",
        "task_replan_period_s",
        "model_deterring_risk_threshold",
        "model_deterring_budget_per_robot_per_hr",
        "model_deterring_window_s",
        "beta_true",
        "baseline",
        "assignment_method",
    ]
    for keys, g in runs_df.groupby(gcols, as_index=False):
        row = {name: val for name, val in zip(gcols, keys)}
        row["n_runs"] = int(len(g))
        for m in metrics:
            st = _stats(g, m)
            row[f"{m}_mean"] = st["mean"]
            row[f"{m}_std"] = st["std"]
            row[f"{m}_ci95"] = st["ci95"]
        out.append(row)
    return pd.DataFrame(out)


def build_method_deltas_vs_frozen(runs_df: pd.DataFrame) -> pd.DataFrame:
    if runs_df.empty:
        return pd.DataFrame()
    keys = ["scenario_id", "baseline", "seed", "run_idx"]
    base = runs_df[runs_df["assignment_method"] == "frozen_greedy"].copy()
    methods = sorted({m for m in runs_df["assignment_method"].unique() if m != "frozen_greedy"})
    out = []
    for method in methods:
        cur = runs_df[runs_df["assignment_method"] == method].copy()
        pair = cur.merge(base, on=keys, suffixes=("_m", "_f"), how="inner")
        if pair.empty:
            continue
        pair["assignment_method"] = method
        den_e = pair["value_weighted_exposure_f"].replace(0.0, np.nan)
        den_r = pair["mean_response_time_s_f"].replace(0.0, np.nan)
        den_c = pair["boundary_message_count_f"].replace(0.0, np.nan)
        pair["delta_exposure_pct"] = 100.0 * (pair["value_weighted_exposure_f"] - pair["value_weighted_exposure_m"]) / den_e
        pair["delta_response_pct"] = 100.0 * (pair["mean_response_time_s_f"] - pair["mean_response_time_s_m"]) / den_r
        pair["delta_comm_pct"] = 100.0 * (pair["boundary_message_count_m"] - pair["boundary_message_count_f"]) / den_c
        g = pair.groupby(["scenario_id", "baseline", "assignment_method"], as_index=False).agg(
            delta_exposure_pct_mean=("delta_exposure_pct", "mean"),
            delta_response_pct_mean=("delta_response_pct", "mean"),
            delta_comm_pct_mean=("delta_comm_pct", "mean"),
        )
        out.append(g)
    return pd.concat(out, ignore_index=True) if out else pd.DataFrame()


def build_proposed_vs_prediction_deltas(runs_df: pd.DataFrame) -> pd.DataFrame:
    if runs_df.empty:
        return pd.DataFrame()
    out = []
    methods = sorted({str(m) for m in runs_df["assignment_method"].dropna().unique()})
    scenarios = sorted({str(s) for s in runs_df["scenario_id"].dropna().unique()})
    for scenario in scenarios:
        for method in methods:
            p = runs_df[
                (runs_df["scenario_id"] == scenario)
                & (runs_df["assignment_method"] == method)
                & (runs_df["baseline"] == "proposed")
            ]
            q = runs_df[
                (runs_df["scenario_id"] == scenario)
                & (runs_df["assignment_method"] == method)
                & (runs_df["baseline"] == "prediction_only")
            ]
            pair = p.merge(q, on=["scenario_id", "assignment_method", "seed", "run_idx"], suffixes=("_p", "_q"), how="inner")
            if pair.empty:
                continue
            den_e = pair["value_weighted_exposure_q"].replace(0.0, np.nan)
            den_r = pair["mean_response_time_s_q"].replace(0.0, np.nan)
            den_c = pair["boundary_message_count_q"].replace(0.0, np.nan)
            exp_imp = 100.0 * (pair["value_weighted_exposure_q"] - pair["value_weighted_exposure_p"]) / den_e
            resp_imp = 100.0 * (pair["mean_response_time_s_q"] - pair["mean_response_time_s_p"]) / den_r
            comm_inc = 100.0 * (pair["boundary_message_count_p"] - pair["boundary_message_count_q"]) / den_c
            p0 = p.iloc[0]
            out.append(
                {
                    "scenario_id": scenario,
                    "assignment_method": method,
                    "assignment_distance_cost_per_m": float(p0.get("assignment_distance_cost_per_m", np.nan)),
                    "assignment_switch_penalty": float(p0.get("assignment_switch_penalty", np.nan)),
                    "task_replan_period_s": float(p0.get("task_replan_period_s", np.nan)),
                    "model_deterring_risk_threshold": float(p0.get("model_deterring_risk_threshold", np.nan)),
                    "model_deterring_budget_per_robot_per_hr": float(
                        p0.get("model_deterring_budget_per_robot_per_hr", np.nan)
                    ),
                    "model_deterring_window_s": float(p0.get("model_deterring_window_s", np.nan)),
                    "beta_true": float(p0.get("beta_true", np.nan)),
                    "exp_improve_pct_mean": float(np.nanmean(exp_imp)),
                    "resp_improve_pct_mean": float(np.nanmean(resp_imp)),
                    "comm_increase_pct_mean": float(np.nanmean(comm_inc)),
                    "runtime_ms_mean": float(np.nanmean(pd.to_numeric(p["assignment_solver_runtime_ms"], errors="coerce"))),
                    "failures_mean": float(np.nanmean(pd.to_numeric(p["assignment_solver_failures"], errors="coerce"))),
                }
            )
    return pd.DataFrame(out)


def choose_best_hungarian(deltas_df: pd.DataFrame) -> dict:
    if deltas_df.empty:
        return {"best_scenario": None, "reason": "empty deltas"}
    h = deltas_df[deltas_df["assignment_method"] == "hungarian"].copy()
    if h.empty:
        return {"best_scenario": None, "reason": "no hungarian rows"}

    h["hard_reject"] = (h["failures_mean"] > 0.0) | ((h["comm_increase_pct_mean"] > 100.0) & (h["exp_improve_pct_mean"] < 0.5))
    cand = h[~h["hard_reject"]].copy()
    if cand.empty:
        return {"best_scenario": None, "reason": "all hungarian scenarios hard-rejected"}
    cand = cand.sort_values(
        by=["exp_improve_pct_mean", "resp_improve_pct_mean", "comm_increase_pct_mean", "runtime_ms_mean", "scenario_id"],
        ascending=[False, False, True, True, True],
    )
    best = cand.iloc[0].to_dict()
    return {"best_scenario": str(best["scenario_id"]), "row": best}


def build_phase1_summary(deltas_df: pd.DataFrame) -> pd.DataFrame:
    if deltas_df.empty:
        return pd.DataFrame()
    cols = [
        "scenario_id",
        "assignment_method",
        "exp_improve_pct_mean",
        "resp_improve_pct_mean",
        "comm_increase_pct_mean",
        "runtime_ms_mean",
        "failures_mean",
    ]
    out = deltas_df[cols].copy()
    out["hard_reject"] = (out["failures_mean"] > 0.0) | (
        (out["comm_increase_pct_mean"] > 100.0) & (out["exp_improve_pct_mean"] < 0.5)
    )
    out = out.sort_values(
        by=[
            "assignment_method",
            "hard_reject",
            "exp_improve_pct_mean",
            "resp_improve_pct_mean",
            "comm_increase_pct_mean",
            "runtime_ms_mean",
            "scenario_id",
        ],
        ascending=[True, True, False, False, True, True, True],
    )
    return out


def build_phase2_ranking(deltas_df: pd.DataFrame) -> pd.DataFrame:
    if deltas_df.empty:
        return pd.DataFrame()
    cols = [
        "scenario_id",
        "assignment_method",
        "assignment_distance_cost_per_m",
        "assignment_switch_penalty",
        "task_replan_period_s",
        "model_deterring_risk_threshold",
        "model_deterring_budget_per_robot_per_hr",
        "model_deterring_window_s",
        "beta_true",
        "exp_improve_pct_mean",
        "resp_improve_pct_mean",
        "comm_increase_pct_mean",
        "runtime_ms_mean",
        "failures_mean",
    ]
    out = deltas_df[cols].copy()
    out["hard_reject"] = out["failures_mean"] > 0.0
    out = out.sort_values(
        by=[
            "hard_reject",
            "exp_improve_pct_mean",
            "resp_improve_pct_mean",
            "comm_increase_pct_mean",
            "runtime_ms_mean",
            "scenario_id",
        ],
        ascending=[True, False, False, True, True, True],
    ).reset_index(drop=True)
    out["rank"] = 0
    ok = ~out["hard_reject"]
    out.loc[ok, "rank"] = np.arange(1, int(ok.sum()) + 1, dtype=int)
    return out


def _parse_phase1_scenario_id(s: str) -> dict | None:
    """
    Parses phase1 scenario id pattern:
      d<dist>_s<switch>_rp<replan>
    optionally with extra suffixes.
    """
    import re

    m = re.search(r"d(?P<d>[-+]?[0-9]*\.?[0-9]+)_s(?P<s>[-+]?[0-9]*\.?[0-9]+)_rp(?P<rp>[0-9]+)", str(s))
    if not m:
        return None
    return {
        "assignment_distance_cost_per_m": float(m.group("d")),
        "assignment_switch_penalty": float(m.group("s")),
        "task_replan_period_s": int(m.group("rp")),
    }


def _load_phase1_winner_config(manifest_path: Path) -> dict:
    data = json.loads(manifest_path.read_text(encoding="utf-8"))
    winner = data.get("best_hungarian_scenario", {})
    scenario = winner.get("best_scenario")
    row = winner.get("row", {})
    parsed = _parse_phase1_scenario_id(str(scenario))
    if parsed is None:
        raise ValueError(f"Could not parse phase1 winner scenario_id: {scenario}")
    method = str(row.get("assignment_method", "hungarian")).strip().lower()
    if method != "hungarian":
        raise ValueError(f"Phase1 winner method is not hungarian: {method}")
    return parsed


def main() -> None:
    parser = argparse.ArgumentParser(description="Hungarian-focused assignment tuning sweep (lab only)")
    parser.add_argument("--stage", type=str, choices=["phase1", "phase2"], default="phase1")
    parser.add_argument("--num-runs", type=int, default=8)
    parser.add_argument("--seed-start", type=int, default=2000)
    parser.add_argument("--t-end", type=float, default=3 * 3600.0)
    parser.add_argument("--dt", type=float, default=5.0)
    parser.add_argument("--baselines", type=str, default="prediction_only,proposed")
    parser.add_argument("--methods", type=str, default="frozen_greedy,hungarian")
    parser.add_argument("--distance-costs", type=str, default="0.004,0.005,0.006,0.008")
    parser.add_argument("--switch-penalties", type=str, default="0.4,0.5,0.7,1.0")
    parser.add_argument("--replan-periods", type=str, default="75,90,105")
    parser.add_argument("--risk-thresholds", type=str, default="")
    parser.add_argument("--budget-per-hr", type=str, default="")
    parser.add_argument("--deterring-windows", type=str, default="")
    parser.add_argument("--beta-true-values", type=str, default="")
    parser.add_argument("--phase1-manifest", type=str, default="")
    parser.add_argument(
        "--use-phase1-winner",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="For stage=phase2, load fixed Hungarian dispatch config from phase1 manifest.",
    )
    parser.add_argument("--outdir", type=str, default="results/assignment_tuning_sweep_lab")
    parser.add_argument(
        "--resume",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Resume from scenario-level checkpoint (default: enabled).",
    )
    parser.add_argument(
        "--checkpoint-path",
        type=str,
        default="",
        help="Optional checkpoint CSV path. Default: <outdir>/assignment_tuning_runs_lab.checkpoint.csv",
    )
    parser.add_argument(
        "--max-workers",
        type=int,
        default=1,
        help="Process workers for parallel scenario execution; use 0 for auto (cpu_count-1).",
    )
    args = parser.parse_args()

    if getattr(ds, "mon", None) is not None:
        ds.mon.enabled = False

    baselines = _parse_str_list(args.baselines)
    methods = _parse_str_list(args.methods)
    distance_costs = _parse_float_list(args.distance_costs)
    switch_penalties = _parse_float_list(args.switch_penalties)
    replan_periods_s = _parse_int_list(args.replan_periods)
    risk_thresholds = _parse_float_list(args.risk_thresholds)
    budget_per_hr = _parse_int_list(args.budget_per_hr)
    deterring_window_s = _parse_float_list(args.deterring_windows)
    beta_true_values = _parse_float_list(args.beta_true_values)

    stage = str(args.stage).strip().lower()
    if stage == "phase1":
        if not risk_thresholds:
            risk_thresholds = [0.35]
        if not budget_per_hr:
            budget_per_hr = [4]
        if not deterring_window_s:
            deterring_window_s = [90.0]
        if not beta_true_values:
            beta_true_values = [0.35]

    if stage == "phase2":
        # Force phase2 comparison to fixed Hungarian assignment as requested.
        methods = ["hungarian"]
        if bool(args.use_phase1_winner):
            if str(args.phase1_manifest).strip():
                p1_manifest = Path(args.phase1_manifest)
            else:
                p1_manifest = Path("results/assignment_tuning_sweep_lab_phase1_fast/assignment_tuning_manifest_lab.json")
            cfg = _load_phase1_winner_config(p1_manifest)
            distance_costs = [float(cfg["assignment_distance_cost_per_m"])]
            switch_penalties = [float(cfg["assignment_switch_penalty"])]
            replan_periods_s = [int(cfg["task_replan_period_s"])]
            print(
                "[phase2] fixed dispatch from phase1 winner: "
                f"d={distance_costs[0]} s={switch_penalties[0]} rp={replan_periods_s[0]} "
                f"(manifest={p1_manifest})"
            )
        # Phase2 required sweep knobs defaults.
        if not risk_thresholds:
            risk_thresholds = [0.25, 0.35, 0.45]
        if not budget_per_hr:
            budget_per_hr = [3, 5, 7]
        if not deterring_window_s:
            deterring_window_s = [90.0, 120.0]
        if not beta_true_values:
            beta_true_values = [0.25, 0.35, 0.45]

    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    checkpoint_path = Path(args.checkpoint_path) if str(args.checkpoint_path).strip() else (
        outdir / "assignment_tuning_runs_lab.checkpoint.csv"
    )

    base_params = _build_base_params(float(args.t_end), float(args.dt))
    runs_df = run_sweep(
        num_runs=int(args.num_runs),
        seed_start=int(args.seed_start),
        baselines=baselines,
        methods=methods,
        distance_costs=distance_costs,
        switch_penalties=switch_penalties,
        replan_periods_s=replan_periods_s,
        risk_thresholds=risk_thresholds,
        budget_per_hr=budget_per_hr,
        deterring_window_s=deterring_window_s,
        beta_true_values=beta_true_values,
        base_params=base_params,
        checkpoint_path=checkpoint_path,
        resume=bool(args.resume),
        max_workers=int(args.max_workers),
    )
    summary_df = build_summary(runs_df)
    method_deltas_df = build_method_deltas_vs_frozen(runs_df)
    baseline_deltas_df = build_proposed_vs_prediction_deltas(runs_df)
    phase1_summary_df = build_phase1_summary(baseline_deltas_df)
    phase2_ranking_df = build_phase2_ranking(baseline_deltas_df)
    best = choose_best_hungarian(baseline_deltas_df)

    runs_path = outdir / "assignment_tuning_runs_lab.csv"
    summary_path = outdir / "assignment_tuning_summary_lab.csv"
    method_deltas_path = outdir / "assignment_tuning_method_deltas_lab.csv"
    baseline_deltas_path = outdir / "assignment_tuning_proposed_vs_prediction_lab.csv"
    phase1_summary_path = outdir / "assignment_tuning_phase1_summary_lab.csv"
    phase2_ranking_path = outdir / "assignment_tuning_phase2_ranking_lab.csv"
    manifest_path = outdir / "assignment_tuning_manifest_lab.json"

    runs_df.to_csv(runs_path, index=False)
    summary_df.to_csv(summary_path, index=False)
    method_deltas_df.to_csv(method_deltas_path, index=False)
    baseline_deltas_df.to_csv(baseline_deltas_path, index=False)
    phase1_summary_df.to_csv(phase1_summary_path, index=False)
    phase2_ranking_df.to_csv(phase2_ranking_path, index=False)

    manifest = {
        "num_runs": int(args.num_runs),
        "seed_start": int(args.seed_start),
        "seed_list": [int(args.seed_start) + i for i in range(int(args.num_runs))],
        "t_end": float(args.t_end),
        "dt": float(args.dt),
        "baselines": baselines,
        "methods": methods,
        "stage": stage,
        "distance_costs": distance_costs,
        "switch_penalties": switch_penalties,
        "replan_periods_s": replan_periods_s,
        "model_deterring_risk_thresholds": risk_thresholds,
        "model_deterring_budget_per_robot_per_hr": budget_per_hr,
        "model_deterring_window_s": deterring_window_s,
        "beta_true_values": beta_true_values,
        "phase1_manifest": str(args.phase1_manifest),
        "use_phase1_winner": bool(args.use_phase1_winner),
        "resume": bool(args.resume),
        "checkpoint_path": str(checkpoint_path),
        "max_workers": int(args.max_workers),
        "best_hungarian_scenario": best,
    }
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    print(f"[done] wrote outputs to: {outdir}")
    print(f"- {runs_path}")
    print(f"- {summary_path}")
    print(f"- {method_deltas_path}")
    print(f"- {baseline_deltas_path}")
    print(f"- {phase1_summary_path}")
    print(f"- {phase2_ranking_path}")
    print(f"- {manifest_path}")


if __name__ == "__main__":
    main()
