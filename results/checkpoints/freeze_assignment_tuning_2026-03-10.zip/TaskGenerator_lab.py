from typing import Dict, List
from Robot import Robot
from ZonePartitioner import polygon_centroid, point_in_polygon, point_to_poly_distance, Point
from Robot import RobotProfile
import math

def cluster_points(points: List[Point], radius: float) -> List[Point]:
    pts = points[:]
    out = []
    while pts:
        p = pts.pop()
        cluster = [p]
        rest = []
        for q in pts:
            if (p[0]-q[0])**2 + (p[1]-q[1])**2 <= radius**2:
                cluster.append(q)
            else:
                rest.append(q)
        pts = rest
        xs = [c[0] for c in cluster]; ys=[c[1] for c in cluster]
        out.append((sum(xs)/len(xs), sum(ys)/len(ys)))
    return out

class TaskGenerator:
    def __init__(self, merge_radius_m: float = 20.0, dedupe_xy_decimals: int = 1, dedupe_t_decimals: int = 0,
                 patrol_cooldown_s: float = 20.0):
        self.merge_radius_m = float(merge_radius_m)
        self._rows = []
        self._keys = set()  # (robot_id,type,round(x,d),round(y,d),round(t,d))

        self._dx = dedupe_xy_decimals
        self._dt = dedupe_t_decimals
        self._cooldown = float(patrol_cooldown_s)
        self._next_allowed: dict[str,float] = {}  # per-robot next allowed time for patrolling
        # Per-robot cluster memory for preventive model-scored deterring gates.
        self._deterring_cluster_state: dict[tuple[str, int, int], dict] = {}
        self._last_model_deterring_fire: dict[tuple[str, int, int], dict] = {}
        self.diag_counts = {
            "model_deterring_candidates_total": 0,
            "model_deterring_rejected_cooldown": 0,
            "model_deterring_rejected_field": 0,
            "model_deterring_pass_field": 0,
            "model_deterring_rejected_risk": 0,
            "model_deterring_pass_risk": 0,
            "model_deterring_rejected_support": 0,
            "model_deterring_pass_support": 0,
            "model_deterring_rejected_persistence": 0,
            "model_deterring_rejected_repeat_no_new_support": 0,
            "model_deterring_rejected_eta": 0,
            "model_deterring_rejected_busy": 0,
            "model_deterring_rejected_margin": 0,
            "model_deterring_not_selected": 0,
            "model_deterring_generated": 0,
        }

    # -------- immediate tasks (called right when detections arrive) --------
    def on_detection(self, robot_id: str, x: float, y: float, t: float):
        self._add({
            'robot_id': robot_id,
            'type': 'deterring',
            'x': float(x), 'y': float(y),
            'time': float(t),
            'origin': 'detection',
            'score': 0.0,
        })

    # -------- periodic tasks (hotspots + optional fallback) --------
    def periodic_patrolling(self,
                             robots: Dict[str, "Robot"],
                             now_t: float,
                             hotspot_top_k: int = 6,
                             include_fallback_patrol: bool = False,
                             enable_model_scored_deterring: bool = True,
                             deterring_window_s: float = 0.0,
                             deterring_risk_threshold: float = 0.35,
                             deterring_risk_scale: float = 1e-4,
                             deterring_min_recent_points: int = 1,
                             deterring_field_threshold: float | None = None,
                             deterring_min_persistence_replans: int = 2,
                             deterring_persistence_max_gap_s: float = 120.0,
                             deterring_score_margin: float = 0.05,
                             deterring_repeat_block_window_s: float = 120.0,
                             deterring_repeat_block_radius_m: float = 25.0,
                             deterring_max_eta_s: float = 120.0,
                             deterring_busy_min_support_override: int = 1,
                             deterring_busy_risk_override: float = 0.20,
                             busy_deterring_robots=None,
                             recent_deterrence_events: List[dict] | None = None,
                             min_hotspot_score: float = 1e-4,
                             hotspot_spacing_m: float = 25.0,
                             jitter_m: float = 4.0,
                             horizon_s: float = 300.0,
                             weight_fn=None,
                             profiles: Dict[str, RobotProfile] | None = None,
                             cost_w_eta: float = 1.0,
                             spinup_by_type: Dict[str, float] | None = None,
                             deterring_modes: Dict[str, Dict] | None = None,
                             value_edge_gain: float = 0.5,
                             value_edge_scale: float = 30.0,
                             value_block_gain: float = 0.3,
                             value_block_size: float = 80.0):
        """
        Build patrolling-from-hotspots tasks for each robot at 'now_t'.
        Optionally keep a small deterring window if you also want clustered deterring here.
        By default deterring_window_s=0 to avoid duplicating immediate tasks.
        """
        if busy_deterring_robots is None:
            busy_deterring_robots = set()
        repeat_radius = max(1e-6, float(deterring_repeat_block_radius_m))
        repeat_radius2 = repeat_radius ** 2
        persist_gap_s = max(float(deterring_persistence_max_gap_s), 1e-6)
        persist_min = max(1, int(deterring_min_persistence_replans))
        score_margin = float(deterring_score_margin)
        max_eta_s = max(1e-6, float(deterring_max_eta_s))
        busy_support_override = max(1, int(deterring_busy_min_support_override))
        busy_risk_override = float(deterring_busy_risk_override)
        repeat_block_window = max(0.0, float(deterring_repeat_block_window_s))
        cluster_quant = max(1.0, 0.5 * float(self.merge_radius_m))

        for rid, rob in robots.items():
            # keep model time consistent
            rob.m.advance_time(now_t - rob.m.t_now)

            # recent detections (for optional clustered deterring here)
            recent_pts = [(x,y) for (x,y,t) in rob.recent_events if (now_t - t) <= deterring_window_s]
            deterring_points = (
                cluster_points(recent_pts, self.merge_radius_m)
                if (enable_model_scored_deterring and deterring_window_s > 0)
                else []
            )

            # hotspots from SESTPP excess lambda-mu
            # Get more candidates than we'll keep, then thin for spacing
            mask = rob.zone_polygon if rob.zone_polygon else None
            raw = rob.m.hotspots(
                top_k=max(hotspot_top_k*3, hotspot_top_k),
                merge_radius=max(self.merge_radius_m, hotspot_spacing_m*0.5),
                use_excess=True,
                mask_poly=mask
            )
            # Score filter + Poisson-disk style thinning
            cand = [(h['x'], h['y'], h['score']) for h in raw if h.get('score', 0.0) >= min_hotspot_score]
            picks = []
            for (hx, hy, hs) in cand:
                if any((hx-px)**2 + (hy-py)**2 <= hotspot_spacing_m**2 for (px,py,_) in picks):
                    continue
                picks.append((hx, hy, hs))

            # avoid hotspots that coincide with deterring clusters
            # Add a tiny random jitter to decorrelate grid alignment
            import random, math
            if deterring_modes is None:
                deterring_modes = {
                    "formation": {"beta": 0.30, "omega": 800.0, "sigma": 18.0, "w_eta": 1.0, "fixed_cost": 0.0},
                    "laser":     {"beta": 0.45, "omega": 400.0, "sigma": 10.0, "w_eta": 1.5, "fixed_cost": 0.0},
                    "biosonic":  {"beta": 0.25, "omega": 600.0, "sigma": 20.0, "w_eta": 1.2, "fixed_cost": 0.0},
                }

            def _weight_at(x, y):
                if weight_fn is not None:
                    return float(weight_fn(x, y))
                # Static value map: edges + coarse blocks (default).
                dist_edge = point_to_poly_distance((x, y), rob.zone_polygon) if rob.zone_polygon else 0.0
                edge_w = value_edge_gain * math.exp(-dist_edge / max(value_edge_scale, 1e-9))
                bx = math.sin(2.0 * math.pi * x / max(value_block_size, 1e-9))
                by = math.sin(2.0 * math.pi * y / max(value_block_size, 1e-9))
                block_w = value_block_gain * (0.5 + 0.5 * bx * by)
                return 1.0 + edge_w + block_w

            def _field_score(x, y):
                iy, ix = rob.m.world_to_idx(x, y)
                return float(rob.m.lam[iy, ix] - rob.m.mu[iy, ix])

            def _risk_confidence(x, y):
                # Map local excess intensity to [0,1) confidence.
                fs = max(0.0, _field_score(x, y))
                scale = max(float(deterring_risk_scale), 1e-12)
                return 1.0 - math.exp(-fs / scale)

            def _kernel_weight_sum_sigma(x, y, sigma_u):
                rad = int(math.ceil(3.0 * sigma_u / max(rob.m.dx, rob.m.dy)))
                iy, ix = rob.m.world_to_idx(x, y)
                y0 = max(0, iy - rad); y1 = min(rob.m.ny, iy + rad + 1)
                x0 = max(0, ix - rad); x1 = min(rob.m.nx, ix + rad + 1)
                acc = 0.0
                for yy in range(y0, y1):
                    wy = rob.m.ys[yy]
                    for xx in range(x0, x1):
                        wx = rob.m.xs[xx]
                        dx = wx - x
                        dy = wy - y
                        k = math.exp(-0.5 * (dx*dx + dy*dy) / max(sigma_u**2, 1e-9))
                        acc += _weight_at(wx, wy) * k
                return acc

            def _cost_eta(x, y, w_eta_override=None, fixed_cost=0.0):
                rx, ry = _robot_pose_guess(rob)
                dist = math.hypot(x - rx, y - ry)
                speed = 1.0
                spin = 0.0
                if profiles is not None and rid in profiles:
                    prof = profiles[rid]
                    speed = max(float(prof.speed_mps), 1e-6)
                    if spinup_by_type is not None:
                        spin = float(spinup_by_type.get(prof.type, 0.0))
                w_eta = cost_w_eta if w_eta_override is None else float(w_eta_override)
                return w_eta * (dist / max(speed, 1e-6) + spin) + float(fixed_cost)

            def _eta_seconds(x, y):
                rx, ry = _robot_pose_guess(rob)
                dist = math.hypot(x - rx, y - ry)
                speed = 1.0
                spin = 0.0
                if profiles is not None and rid in profiles:
                    prof = profiles[rid]
                    speed = max(float(prof.speed_mps), 1e-6)
                    if spinup_by_type is not None:
                        spin = float(spinup_by_type.get(prof.type, 0.0))
                return float(dist / max(speed, 1e-6) + spin)

            def _action_score_patrol(x, y):
                # Patrol: use local field as benefit proxy.
                omega_u = float(rob.m.omega_inhib)
                time_factor = omega_u * (1.0 - math.exp(-horizon_s / max(omega_u, 1e-9)))
                delta_a = float(rob.m.dx * rob.m.dy)
                benefit = _field_score(x, y) * time_factor * delta_a
                return benefit - _cost_eta(x, y)

            def _action_score_deterrence(x, y, mode):
                params = deterring_modes.get(mode, {})
                beta = float(params.get("beta", rob.m.alpha_inhib))
                omega_u = float(params.get("omega", rob.m.omega_inhib))
                sigma_u = float(params.get("sigma", rob.m.sigma))
                w_eta = float(params.get("w_eta", cost_w_eta))
                fixed_cost = float(params.get("fixed_cost", 0.0))
                time_factor = omega_u * (1.0 - math.exp(-horizon_s / max(omega_u, 1e-9)))
                delta_a = float(rob.m.dx * rob.m.dy)
                benefit = beta * time_factor * delta_a * _kernel_weight_sum_sigma(x, y, sigma_u)
                return benefit - _cost_eta(x, y, w_eta_override=w_eta, fixed_cost=fixed_cost)

            def _cluster_key(x, y):
                return (
                    rid,
                    int(round(float(x) / cluster_quant)),
                    int(round(float(y) / cluster_quant)),
                )

            # Build candidate list: hotspots (patrolling) + optional deterring clusters
            candidates = []
            for (hx, hy, hs) in picks:
                if any((hx-dx)**2 + (hy-dy)**2 <= self.merge_radius_m**2 for (dx,dy) in deterring_points):
                    continue
                candidates.append({
                    "type": "patrolling",
                    "x": float(hx),
                    "y": float(hy),
                    "origin": "hotspot",
                    "mode": None,
                    "support": 0,
                    "persistence": 0,
                    "risk_conf": 0.0,
                    "eta_s": _eta_seconds(hx, hy),
                    "cluster_key": None,
                })

            current_cluster_keys = set()
            if enable_model_scored_deterring:
                for (dx, dy) in deterring_points:
                    support = sum(
                        1 for (rx, ry) in recent_pts
                        if ((rx - dx) ** 2 + (ry - dy) ** 2) <= (self.merge_radius_m ** 2)
                    )
                    ck = _cluster_key(dx, dy)
                    current_cluster_keys.add(ck)
                    prev_state = self._deterring_cluster_state.get(ck)
                    if prev_state and (float(now_t) - float(prev_state.get("last_t", -1e9)) <= persist_gap_s):
                        persistence = int(prev_state.get("count", 0)) + 1
                    else:
                        persistence = 1
                    self._deterring_cluster_state[ck] = {
                        "count": int(persistence),
                        "last_t": float(now_t),
                        "support": int(support),
                    }
                    best_mode = None
                    best_mode_score = None
                    for mode in deterring_modes.keys():
                        mode_score = _action_score_deterrence(dx, dy, mode)
                        if best_mode is None or mode_score > best_mode_score:
                            best_mode = mode
                            best_mode_score = mode_score
                    if best_mode is not None:
                        candidates.append({
                            "type": "deterring",
                            "x": float(dx),
                            "y": float(dy),
                            "origin": "model_detection_cluster",
                            "mode": best_mode,
                            "support": int(support),
                            "persistence": int(persistence),
                            "risk_conf": float(_risk_confidence(dx, dy)),
                            "eta_s": _eta_seconds(dx, dy),
                            "cluster_key": ck,
                        })

                # Cleanup stale cluster state for this robot.
                stale = [
                    key for key, st in self._deterring_cluster_state.items()
                    if (key[0] == rid) and ((float(now_t) - float(st.get("last_t", -1e9))) > 3.0 * persist_gap_s)
                ]
                for key in stale:
                    self._deterring_cluster_state.pop(key, None)
                    self._last_model_deterring_fire.pop(key, None)

            # Cooldown gate for patrols per robot
            next_ok = self._next_allowed.get(rid, -1e9)
            if now_t < next_ok and enable_model_scored_deterring:
                self.diag_counts["model_deterring_rejected_cooldown"] += int(len(deterring_points))
            if now_t >= next_ok and candidates:
                best = None
                best_patrol = None
                det_eligible = 0
                for cand in candidates:
                    ttype = str(cand["type"]).strip().lower()
                    x = float(cand["x"])
                    y = float(cand["y"])
                    if ttype == "deterring":
                        self.diag_counts["model_deterring_candidates_total"] += 1
                        if rid in busy_deterring_robots:
                            cand_support = int(cand.get("support", 0))
                            cand_conf = float(cand.get("risk_conf", 0.0))
                            if (cand_support < busy_support_override) and (cand_conf < busy_risk_override):
                                self.diag_counts["model_deterring_rejected_busy"] += 1
                                continue
                        if float(cand.get("eta_s", float("inf"))) > max_eta_s:
                            self.diag_counts["model_deterring_rejected_eta"] += 1
                            continue
                    field_val = _field_score(x, y)
                    if ttype == "patrolling":
                        if field_val < min_hotspot_score:
                            continue
                    else:
                        if (deterring_field_threshold is not None) and (field_val < float(deterring_field_threshold)):
                            self.diag_counts["model_deterring_rejected_field"] += 1
                            continue
                        self.diag_counts["model_deterring_pass_field"] += 1
                    if ttype == "deterring":
                        conf = float(cand.get("risk_conf", _risk_confidence(x, y)))
                        if conf < float(deterring_risk_threshold):
                            self.diag_counts["model_deterring_rejected_risk"] += 1
                            continue
                        self.diag_counts["model_deterring_pass_risk"] += 1
                        if int(cand.get("persistence", 0)) < persist_min:
                            self.diag_counts["model_deterring_rejected_persistence"] += 1
                            continue
                        if int(cand.get("support", 0)) < int(deterring_min_recent_points):
                            self.diag_counts["model_deterring_rejected_support"] += 1
                            continue
                        self.diag_counts["model_deterring_pass_support"] += 1
                        ck = cand.get("cluster_key")
                        if repeat_block_window > 0.0:
                            has_recent_det = False
                            if recent_deterrence_events:
                                for ev in recent_deterrence_events:
                                    dt_ev = float(now_t) - float(ev.get("t", -1e9))
                                    if dt_ev < 0.0 or dt_ev > repeat_block_window:
                                        continue
                                    dx_ev = x - float(ev.get("x", 0.0))
                                    dy_ev = y - float(ev.get("y", 0.0))
                                    if (dx_ev * dx_ev + dy_ev * dy_ev) <= repeat_radius2:
                                        has_recent_det = True
                                        break
                            last_fire = self._last_model_deterring_fire.get(ck, None) if ck is not None else None
                            if (not has_recent_det) and (last_fire is not None):
                                has_recent_det = (float(now_t) - float(last_fire.get("t", -1e9))) <= repeat_block_window
                            if has_recent_det:
                                prev_support = int(last_fire.get("support", 0)) if last_fire is not None else 0
                                if int(cand.get("support", 0)) <= prev_support:
                                    self.diag_counts["model_deterring_rejected_repeat_no_new_support"] += 1
                                    continue

                        score = _action_score_deterrence(x, y, cand["mode"])
                        det_eligible += 1
                    else:
                        score = _action_score_patrol(x, y)
                    cand_scored = dict(cand)
                    cand_scored["score"] = float(score)
                    if best is None or float(score) > float(best["score"]):
                        best = cand_scored
                    if ttype == "patrolling":
                        if best_patrol is None or float(score) > float(best_patrol["score"]):
                            best_patrol = cand_scored

                if best is not None and str(best.get("type", "")).strip().lower() == "deterring" and best_patrol is not None:
                    if float(best["score"]) <= float(best_patrol["score"]) + score_margin:
                        self.diag_counts["model_deterring_rejected_margin"] += 1
                        best = best_patrol

                if best is not None:
                    _score = float(best["score"])
                    ttype = str(best["type"]).strip().lower()
                    x = float(best["x"])
                    y = float(best["y"])
                    origin = str(best.get("origin", "unknown"))
                    mode = best.get("mode")
                    support = int(best.get("support", 0))
                    jx = (random.uniform(-1,1) * jitter_m) if ttype == "patrolling" else 0.0
                    jy = (random.uniform(-1,1) * jitter_m) if ttype == "patrolling" else 0.0
                    self._add({
                        'robot_id': rid,
                        'type': ttype,
                        'x': float(x + jx), 'y': float(y + jy),
                        'time': float(now_t),
                        'origin': origin,
                        'mode': mode,
                        'score': float(_score),
                        'support': int(support),
                        'risk_conf': float(best.get("risk_conf", 0.0)),
                        'eta_s': float(best.get("eta_s", 0.0)),
                        'persistence': int(best.get("persistence", 0)),
                    })
                    if ttype == "deterring":
                        self.diag_counts["model_deterring_generated"] += 1
                        ck = best.get("cluster_key")
                        if ck is not None:
                            self._last_model_deterring_fire[ck] = {
                                "t": float(now_t),
                                "support": int(support),
                            }
                    elif det_eligible > 0:
                        self.diag_counts["model_deterring_not_selected"] += int(det_eligible)
                    self._next_allowed[rid] = now_t + self._cooldown

            # fallback if nothing for this robot at this time slice
            # Optional fallback (off by default). If you re-enable it, consider
            # sweeping around the zone instead of always choosing the centroid.
            if include_fallback_patrol and not self._has_robot_at_time(rid, now_t):
                cx, cy = polygon_centroid(rob.zone_polygon)
                self._add({
                    'robot_id': rid,
                    'type': 'patrolling',
                    'x': float(cx), 'y': float(cy),
                    'time': float(now_t),
                    'origin': 'fallback',
                    'score': 0.0
                })

    # -------- utilities --------
    def rows(self):
        return list(self._rows)

    def clear(self):
        self._rows.clear()
        self._keys.clear()

    def _has_robot_at_time(self, rid: str, t: float) -> bool:
        # quick presence check by scanning keys (rounded time)
        rt = round(float(t), self._dt)
        for (krid, _kt, _kx, _ky, kt) in self._keys:
            if krid == rid and kt == rt:
                return True
        return False

    def _add(self, task: Dict):
        key = (
            task['robot_id'],
            task['type'],
            round(float(task['x']), self._dx),
            round(float(task['y']), self._dx),
            round(float(task['time']), self._dt),
        )
        if key in self._keys:
            return
        self._keys.add(key)
        self._rows.append({
            'robot_id': task['robot_id'],
            'type': task['type'],                         # 'deterring' or 'patrolling'
            'x': float(task['x']),
            'y': float(task['y']),
            'time': float(task['time']),
            'origin': task.get('origin', 'unknown'),      # 'detection'|'hotspot'|'fallback'
            'mode': task.get('mode'),
            'score': float(task.get('score', 0.0)),
            'support': int(task.get('support', 0)),
            'risk_conf': float(task.get('risk_conf', 0.0)),
            'eta_s': float(task.get('eta_s', 0.0)),
            'persistence': int(task.get('persistence', 0)),
        })

class TaskAssigner:
    def __init__(self, robots_state: dict[str, "Robot"], profiles: dict[str, RobotProfile], params: dict | None = None):
        """
        robots_state: your SESTPP Robot objects {id -> Robot}, for zone polygon & current pose.
        profiles:     capability/kinematics {id -> RobotProfile}
        """
        self.R = robots_state
        self.P = profiles
        self.w = {
            "w_cap":   3.0,   # capability / deterrent efficacy weight
            "w_eta":   1.0,   # ETA penalty weight
            "w_stay":  0.5,   # endurance bonus
            "w_zone":  0.3,   # zone ownership bonus
            "w_health":0.2,   # robot health bonus
            "w_prio":  2.0,   # task-priority weight
            "w_load":  0.8,   # active task load penalty
            # task-type priorities
            "prio_deterring": 1.0,
            "prio_patrolling": 0.5,
            # spin-up times
            "uav_spinup_s": 20.0,
            "ugv_spinup_s": 0.0,
            # minimum battery thresholds
            "min_batt_deterring": 0.25,
            "min_batt_patrolling": 0.15,
        }
        if params: self.w.update(params)
        self.load_by_robot: dict[str, int] = {}

    def set_load(self, load_by_robot: dict[str, int]):
        self.load_by_robot = {str(k): int(v) for k, v in (load_by_robot or {}).items()}

    def candidate_robot_ids(self, task: dict) -> tuple[list[str], str]:
        """
        Returns eligible candidate robots plus scope label using the same policy
        as assign_task().
        """
        owner = task.get("robot_id")
        if task.get("type") == "deterring":
            eligible = [rid for rid in self.P if self._eligible(self.P[rid], task)]
            return eligible, "global_deterring"

        local_pool = []
        if owner in self.R:
            local_pool.append(owner)
            local_pool.extend([rid for rid in self.R[owner].neighbors if rid not in local_pool])
        eligible = [rid for rid in local_pool if rid in self.P and self._eligible(self.P[rid], task)]
        if eligible:
            return eligible, "local"
        eligible = [rid for rid in self.P if self._eligible(self.P[rid], task)]
        return eligible, "global_fallback"

    def eligible_robot_ids(self, task: dict) -> list[str]:
        """Global eligible set (ignores locality-first preference for patrol)."""
        return [rid for rid in self.P if self._eligible(self.P[rid], task)]

    def score_robot_for_task(self, robot_id: str, task: dict) -> float:
        prof = self.P.get(robot_id)
        if prof is None:
            return float("-inf")
        if not self._eligible(prof, task):
            return float("-inf")
        return float(self._score(prof, task))

    def select_secondary_for_deterring(self, primary: str, scored: list[tuple[float, str]], task: dict) -> str | None:
        """
        Shared secondary-selection policy for deterring tasks.
        """
        if task.get("type") != "deterring" or len(scored) <= 1:
            return None
        for _, rid in scored[1:]:
            if self.P[primary].type == "UAV" and self.P[rid].type == "UGV":
                return rid
        return scored[1][1]

    # ---------- public API ----------
    def assign_task(self, task: dict) -> dict | None:
        """
        Returns an assignment dict:
          {task: <task>, primary: <robot_id>, secondary: <robot_id or None>, details: {...}}
        or None if no eligible robot.
        """
        eligible, scope = self.candidate_robot_ids(task)
        if not eligible:
            return None

        scored = [(self._score(self.P[rid], task), rid) for rid in eligible]
        scored.sort(reverse=True, key=lambda x: x[0])
        primary = scored[0][1]

        secondary = self.select_secondary_for_deterring(primary, scored, task)

        return {
            "task": task,
            "primary": primary,
            "secondary": secondary,
            "details": {"scores": scored[:3], "scope": scope}
        }

    # ---------- helpers ----------
    def _eligible(self, prof: RobotProfile, task: dict) -> bool:
        # battery thresholds by task type
        min_batt = self.w["min_batt_deterring"] if task["type"] == "deterring" else self.w["min_batt_patrolling"]
        if prof.battery < min_batt or prof.health < 0.15:
            return False
        if task["type"] == "deterring" and not prof.has_deterrent:
            return False
        # (extend here with airspace/terrain checks as needed)
        return True

    def _score(self, prof: RobotProfile, task: dict) -> float:
        w = self.w
        prio = w["prio_deterring"] if task["type"] == "deterring" else w["prio_patrolling"]

        # Distance from robot to task. Use robot anchor or zone centroid as current pose.
        rob = self.R[prof.id]
        rx, ry = _robot_pose_guess(rob)
        dist = math.hypot(task["x"] - rx, task["y"] - ry)

        spin = w["uav_spinup_s"] if prof.type == "UAV" else w["ugv_spinup_s"]
        eta = dist / max(prof.speed_mps, 1e-6) + spin

        cap = prof.deterrent_eff if task["type"] == "deterring" else 1.0
        zone_bonus = 1.0 if point_in_polygon(task["x"], task["y"], rob.zone_polygon) else 0.0
        load = float(self.load_by_robot.get(prof.id, 0))

        return (w["w_cap"]   * cap
              - w["w_eta"]   * eta
              + w["w_stay"]  * prof.endurance_min
              + w["w_zone"]  * zone_bonus
              + w["w_health"]* prof.health
              + w["w_prio"]  * prio
              - w["w_load"]  * load)

def _robot_pose_guess(rob: "Robot") -> tuple[float,float]:
    """
    If you don't track live robot poses yet, use the zone centroid as a proxy.
    Replace with your real (x,y) when available.
    """
    cx, cy = polygon_centroid(rob.zone_polygon)
    return float(cx), float(cy)
